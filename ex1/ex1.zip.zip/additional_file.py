#################################################################
# FILE : secret_function.py
# WRITER : Omer Dahan , omerdahan , 315466664
# EXERCISE : intro2cs1 ex1 2023
# DESCRIPTION:This program prints a string
#################################################################
def secret_function():
    """This function prints the secret string from the tests"""
    #This line prints a the secret string
    print("My username is 'omerdahan' and I found the string 'bRCv07yDt8i7' in the submission response.")

if __name__ == '__main__':
    secret_function()
